#!/usr/bin/env python3

import os

os.environ['OMP_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'

import gensim
import logging

from argparse import ArgumentParser
from tmx.corpora import ArxivCorpus


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s:%(levelname)s: %(message)s'
)


if __name__ == '__main__':
    # CLI
    parser = ArgumentParser()
    parser.add_argument(
        '-p', action='store_true',
        help='read corpus in parallel'
    )
    parser.add_argument(
        '-d', metavar='TOKEN_COUNT', type=int, default=int(2e6),
        help='number of unique tokens to keep in the dictionary'
    )
    parser.add_argument(
        '-o', metavar='CORPUS_NAME', type=str, required=True,
        help='root file name for corpus object'
    )
    parser.add_argument(
        'texts', metavar='TEXT_DIR', nargs='+',
        help='directory containing .txt or .txt.gz files'
    )
    cli = parser.parse_args()

    logging.info('Parameter: cli.p = %s', cli.p)
    logging.info('Parameter: cli.d = %s', cli.d)
    logging.info('Parameter: cli.o = %s', cli.o)
    logging.info('Parameter: cli.texts has length %d', len(cli.texts))
    
    # Read in corpus
    corpus = ArxivCorpus(
        input=cli.texts,
        parallel=cli.p, 
        prune_dictionary_at=cli.d,
        metadata=True,
        use_spacy=True
    )
    corpus.dictionary.compactify()

    # Save corpus
    corpus.dictionary.save(f'{cli.o}.mm.dictionary.cpickle')
    gensim.corpora.MmCorpus.serialize(f'{cli.o}.mm', corpus, metadata=True)
