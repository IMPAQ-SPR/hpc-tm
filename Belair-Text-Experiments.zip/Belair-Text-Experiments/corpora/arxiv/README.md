# Arxiv Corpora

## Early Corpora

These corpora include all of our arXiv extracts. They are named according to the scheme:

    <corpus type>-<subset name or "full">-<max vocab size>-<addl info>

Two corpora include the label *spacy*; these were generated using an early (not-version controlled) class method that used the *spaCy* tokenizer and lemmatizer.

 - `arxiv-full-2M`
 - `arxiv-full-5M`
 - `arxiv-full-5M-spacy`
 - `arxiv-full-10M-spacy`

## More Recent (Better) Corpora

These corpora use a new, version-controlled preprocessing method that also applies *spaCy*'s tokenization and lemmatization. One corpus is "full," and includes all documents. The other two only include documents from 2018.

 - `arxiv-full-20M-spacy`
 - `arxiv-2018-20M-spacy`
 - `arxiv-2018-trunc-spacy`
 - `arxiv-full-trimmed-spacy`
 - `arxiv-full-trimmed-100K-spacy`
 - `arxiv_full_trimmed25K_spacy`
 
The corpus `arxiv-2018-trunc-spacy` is distilled from `arxiv-2018-20M-spacy` and includes only 7,501 unique tokens. This distillation also included a step to merge similar tokens and is implemented in the notebook `20190312-Cut_Down_Arxiv_2018_Vocab.ipynb`.

The corpora `arxiv-full-trimmed-spacy`, `arxiv-full-trimmed-100K-spacy`, and `arxiv_full_trimmed25K_spacy` are derived from the full, 20M-token-limit corpus using the v2 spaCy tokenizer. The first corpus contains all tokens appearing in at least two documents (less than 2M). These tokens were then scrubbed for edge punctuation and either merged with other tokens or dropped, if no matching token existed. The second corpus follows the same process, but starts from the 100K most-common tokens. The third corpus takes the most-common 25K tokens after doing some additional stop word removal.

## Full Listing

| Name                          | Docs | Pipeline            | Notes                                          |
| ---                           | ---  | ---                 | ---                                            |
| arxiv-full-2M                 | All  | By-hand tokenizer   |                                                |
| arxiv-full-5M                 | All  | By-hand tokenizer   |                                                |
| arxiv-full-5M-spacy           | All  | spaCy tokenizer v1  |                                                |
| arxiv-full-10M-spacy          | All  | spaCy tokenizer v1  |                                                |
| arxiv-subset-bow-10K          | All  | spaCy tokenizer v1? | BOW text for Mike                              |
| arxiv-full-20M-spacy          | All  | spaCy tokenizer v2  |                                                |
| arxiv-full-trimmed-spacy      | All  | spaCy tokenizer v2  | All multi-doc tokens; consolidated punctuation | 
| arxiv-full-trimmed-100K-spacy | All  | spaCy tokenizer v2  | Top 100K tokens; consolidated punctuation      |
| arxiv_full_trimmed25K_spacy   | All  | spaCy tokenizer v2  | Top 25K tokens; removed more stop words        |
| arxiv-2018-20M-spacy          | 2018 | spaCy tokenizer v2  |                                                |
| arxiv-2018-trunc-spacy        | 2018 | spaCy tokenizer v2  | Post processed                                 | 
