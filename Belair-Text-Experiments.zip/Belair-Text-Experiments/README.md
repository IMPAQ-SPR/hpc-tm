# Belair HPC Text Mining Experiments

This repository contains data acquisition scripts and source code for carrying out text mining experiments against multiple corpora, including:

 1. [The Project Gutenberg collection][pg]
 2. [The arXiv LaTeX source repository][ax]

[pg]: https://www.gutenberg.org
[ax]: https://arxiv.org


## Acquiring Data

Downloading data archives from S3 requires the AWS command-line tool. The tool isn't configured by default on EC2 instances, so we have to run `aws configure` and supply credentials before any to- or from-S3 scripts will work.


## Python Development

The package *tmx* stands for "text mining experiments".
