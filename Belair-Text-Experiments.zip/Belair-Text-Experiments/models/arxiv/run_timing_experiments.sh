#!/usr/bin/env bash

if [[ $# -ne 2 ]]; then
    echo "Usage: run_timing_experiments.sh BASE_NAME CORPUS_MM_FILE"
    exit 1
fi

BASE_NAME=$1

## JOB CONFIG
CHUNKSIZES=(4096 1024)
EVAL_EVERYS=(0)
ITERATIONS=(500)
PASSES=(1)
SEEDS=(2048)
TOPICS=(100)
WORKERS=(35)

for seed in ${SEEDS[@]}; do
for chunksize in ${CHUNKSIZES[@]}; do
for evalevery in ${EVAL_EVERYS[@]}; do
for nworkers in ${WORKERS[@]}; do
for npasses in ${PASSES[@]}; do
for niters in ${ITERATIONS[@]}; do
for ntopics in ${TOPICS[@]}; do

    # Working directory
    workdir="${BASE_NAME}_t${ntopics}_w${nworkers}_p${npasses}_i${niters}_c${chunksize}_s${seed}_e${evalevery}"
    [[ -d "$workdir" ]] && echo "Skipping $workdir" && continue

    mkdir $workdir && cd $workdir
    echo $workdir

    python3 ../ldamulticore.py \
        -t $ntopics -w $nworkers -i $niters -p $npasses -c $chunksize -s $seed \
        -n "$workdir" -e $evalevery \
        ../$2 \
        &> "ldamulticore.log"

    cd ..
done
done
done
done
done
done
done
