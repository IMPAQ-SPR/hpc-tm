# ArXiv LDA Models

*Note: The number of workers seems to affect convergence. 35 workers x 4096 docs means the models never update and convergence will be bad.*


## Full Listing

*Model tarballs should include log files with full parameter listings.*

| Name                             | Model | Topics | Passes | Iters | 
| ---                              | ---   | ---    | ---    | ---   |
| arxiv-2018-trunc-spacy-01_passes | LDA   | 20     | 1      | 1000  | 
| arxiv-2018-trunc-spacy-05_passes | LDA   | 20     | 5      | 1000  | 
| arxiv-2018-trunc-spacy-10_passes | LDA   | 20     | 10     | 1000  | 
| arxiv-2018-trunc-spacy-20_passes | LDA   | 20     | 20     | 1000  | 

Also see `arxiv/models/first-attempt` in S3, with the same kinds of models on a custom cut-down corpus that I abandoned in favor of the more "canonical" *gensim* way.


## Timings

I ran a bunch of models. 7,500 tokens and about 100,000 documents.

| Workers | Threads | Topics | Passes | Iters | Corpus     | Time |  
| ---     | ---     | ---    | ---    | ---   | ---        | ---  |
| 1       | 1       | 20     | 1      | 200   | 2018-trunc | 6:09 |
| 2       | 1       | 20     | 1      | 200   | 2018-trunc | 2:54 |
| 2       | 3       | 20     | 1      | 200   | 2018-trunc | 3:10 |
| 2       | 3       | 20     | 1      | 200   | 2018-trunc | 3:42 |
| 4       | 1       | 20     | 1      | 200   | 2018-trunc | 1:29 |
| 7       | 1       | 20     | 1      | 200   | 2018-trunc | 1:06 |
