#!/usr/bin/env bash

for workers in {2,}; do
for iterations in {200,}; do
    iterations_str=`printf '%04d' $iterations`
        
    rundir="arxiv-2018-trunc-01passes-${iterations_str}iters-020topics-4096chunks-${workers}workers-nothreading-shards"

        [[ -d "$rundir" ]] && echo "Skipping $rundir" && continue

        echo $rundir && mkdir "$rundir" && cd "$rundir"

        ln -s ../shards shards

        python3 ../ldamulticore.py \
            -t 20 -w $workers -i $iterations -p 1 -c 4096 -s 1024 -n "$rundir" \
            shards/arxiv-2018-trunc-spacy \
            &> "$rundir.log"

        cd ..
done
done
