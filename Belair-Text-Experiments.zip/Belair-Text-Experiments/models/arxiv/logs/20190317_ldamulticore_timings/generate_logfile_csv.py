
import os
import pandas as pd
import re

from argparse import ArgumentParser
from dateutil import parser as date_parser


if __name__ == '__main__':
    parser = ArgumentParser(
        description='generate CSVs from LDAMulticore log files')
    parser.add_argument('files', metavar='<logfile>', type=str, nargs='+', 
        help='ldamulticore.py log files')
    cli = parser.parse_args()

    RE_NUMBER = re.compile(r'^[0-9. ]+$')
    df = []
    for file in cli.files:
        # Extract the timings and parameters
        with open(file, 'r') as infil:
            time_start = time_end = time_delta = -1
            meta_dict = {}
            for line in infil:
                line = line.lower().strip()
                if line.endswith('beginning training'):
                    time_start = date_parser.parse(line.split(',')[0])
                    continue
                if line.endswith('training concluded'):
                    time_end = date_parser.parse(line.split(',')[0])
                    continue
                if line.find('lda param:') != -1:
                    pars = line.split(':')[-2:]
                    if RE_NUMBER.match(pars[-1]):
                        meta_dict[pars[0].strip()] = pars[-1].strip()
                    continue
        time_delta = (time_end-time_start).total_seconds()
        meta_dict['run_time'] = time_delta

        # Get file basename
        basename = os.path.splitext(os.path.basename(file))[0]
        basename = '_'.join([
            m for m in basename.split('_') 
            if not re.match(r'^[a-z]+[0-9]+$', m)
        ])
        meta_dict['name'] = basename
        df += [meta_dict]
    
    pd.DataFrame(df).to_csv('logfiles.csv', index=False)
