# How to Set Up AWS Machines

This directory contains a for-purpose SSH key that is tied directly to this effort's GitHub repository.

1. Use `scp` to upload key `id_rsa` and `setup-machine.sh`:

       scp id_rsa* rmate setup-machine.sh <EC2 URI>

2. Run `bash setup-machine.sh` to install tools and pull the repo.

       ssh <EC2 URI>
       bash setup-machine.sh
       source ~/.bashrc

## Text Processing

To install *pandoc*:
 
  1. Download the linux binaries from [GitHub][pandoc]
  2. Install to `~/bin` and update `$PATH` as appropriate

To install *detex*:
  
  1. Download the linux source from [GitHub][detex]
  2. `make`
  3. Move the binaries to `~/bin`

[panoc]: https://github.com/jgm/pandoc/releases
[detex]: https://github.com/pkubowicz/opendetex/releases
