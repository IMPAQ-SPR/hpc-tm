#!/usr/bin/env bash


# Set up SSH
mv id_rsa* ~/.ssh


# Pull the repository 
sudo yum install -y git
git clone git@github.com:ElderResearch/Belair-Text-Experiments.git work

git config --global user.name "Tom Shafer"
git config --global user.email "tom.shafer@elderresearch.com"


# Install dependencies
sudo yum install -y htop gcc flex-devel gcc-c++
sudo yum install -y \
    python3 \
    python3-devel \
    python3-pip \
    python3-tools \
    python3-wheel

pip3 install --user numpy scipy matplotlib pandas seaborn gensim
pip3 install --user jupyter jupyterlab
pip3 install --user python-magic
# NB this requires spacy-nightly for spacy to be single threaded
pip3 install --user spacy-nightly


# Install rmate, etc
sudo chown root:root rmate
sudo chmod a+x rmate
sudo mv rmate /usr/local/bin/
sudo ln -s /usr/local/bin/rmate /usr/local/bin/code


# Update bashrc
echo '
export PATH="/home/ec2-user/bin:$PATH"
export PYTHONPATH="/home/ec2-user/work:$PYTHONPATH"

alias ls="command ls --color"
alias l="ls -lh"
alias lr="ls -lrth"
alias lt="ls -lrh"
alias ll="ls -l"

alias ..="cd .."
alias ...="cd ../.."
' >> ~/.bashrc
