# TODO

 - [ ] Run 20-topic models on 2018
    - [ ] Serial
    - [ ] 1 worker
    - [ ] 2 workers
    - [ ] 4 workers
    - [ ] 8 workers
    - [ ] 16 workers
    - [ ] 36 workers

 - [ ] Run 20-topic models on full(100K)
    - [ ] Serial
    - [ ] 1 worker
    - [ ] 2 workers
    - [ ] 4 workers
    - [ ] 8 workers
    - [ ] 16 workers
    - [ ] 36 workers

 - [ ] Run 100-topic models on full(100K)
    - [ ] Serial
    - [ ] 1 worker
    - [ ] 2 workers
    - [ ] 4 workers
    - [ ] 8 workers
    - [ ] 16 workers
    - [ ] 36 workers


## Completed

 - [x] Run 20-topic models with 7x1 workers (2018 corpus)
 - [x] Run a single 20-topic model with 2x2 workers (2018 corpus)
 - [x] Run a single 20-topic model with 2x3 workers (2018 corpus)
 - [x] Test with sharded corpus (2018 corpus) [Failed]
 - [x] Create a full corpus with about 100K tokens
