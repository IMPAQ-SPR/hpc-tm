# Research Notes


## 2019-03-19

I ran and collected models with `eval_every=1` to diagnose convergence properties.

I also re-ran the timings for 35 workers with 4096- and 1024-document chunks (`eval_every=0`). I re-ran both because I had to change the CPU affinity when I resized the instance, and I'm not sure that I can make a fair comparison to previous results. IN previous results, only the 35-worker results generated warnings with the whole corpus.

## 2019-03-18

Ran models yesterday and collected results. More cores help, but not as much (off-hand) as might be expected. Also seeing warnings that the models might not converge with a lot of workers; probably because the number of updates is so small:

    updates = <corpus size> / <workers> / <chunk_size> * <passes>
            = 1.06M / 35 / 4096 * 1 ~ 8

It really seems like we don't need a lot of HPC for this; the 1M documents model runs in less than two hours.

(See `models/arxiv/logs/20190317_.../generate-plots.R`.)

### TODO

 - [x] Run `500 iters` x `20 topics` x `eval_every = 1` to assess convergence
 - [x] Run `500 iters` x `20 topics` x `eval_every = 1` x `chunk_size = 1024` 
       to assess convergence with smaller chunk sizes (4 times more updates)
 - [x] Plot timings as they stand for Hautahi
