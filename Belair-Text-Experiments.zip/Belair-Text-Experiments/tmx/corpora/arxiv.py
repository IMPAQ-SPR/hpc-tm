
import logging
logger = logging.getLogger(__name__)

# Incorporate spaCy
import os

try:
    # Disable spacy multithreading
    os.environ['OMP_NUM_THREADS'] = '1'
    os.environ['MKL_NUM_THREADS'] = '1'
    import spacy
    logger.info('spacy module loaded successfully')
except ModuleNotFoundError:
    logger.info('spacy module could not be loaded. spacy is disabled')
    SPACY_IS_AVAILABLE = False
else:
    SPACY_IS_AVAILABLE = True

import gensim
import gzip
import itertools as it
import re

from concurrent import futures


class ArxivCorpus(gensim.corpora.TextCorpus):
    """
    Corpus from arxiv.org source files.
    
    By subclassing corpora.TextCorpus we get much of the wiring for free:
    dictionary support, bag-of-words translation, etc. We can also save to
    other corpus formats.

    The basic chain is:

        input -> get_file_list() -> getstream() -> get_texts() -> ...
                              preprocess_text() ->
    
    The function get_texts() feeds nearly everything: the dictionary, the 
    iteration through the corpus, etc.

    The inclusion of a parallel version of get_texts() is key. It allows us to 
    very quickly read through a large corpus in cases (like building a 
    dictionary) where document order does not matter.
    
    """
    length = None
    parallel = False
    use_spacy = None
    
    def __init__(self, *args, prune_dictionary_at=2000000,
            parallel=False, use_spacy=SPACY_IS_AVAILABLE, **kwargs):
        """
        Bit of a hack to set up parallel=True/False, which is useful for 
        running get_texts() always in parallel.
        
        """
        if parallel:
            self.parallel = True
        self.use_spacy = use_spacy
        self.prune_dictionary_at = int(prune_dictionary_at)
        super().__init__(*args, **kwargs)
    
    def __len__(self):
        """Use self.get_file_list() to count documents"""
        if self.length is not None:
            return self.length
        return sum(1 for _ in self.get_file_list())
    
    def get_file_list(self):
        """Walk through self.input and yield document paths"""
        if self.input is None:
            raise ValueError('self.input must be specified')
        if isinstance(self.input, str):
            self.input = [self.input]
        if any(not os.path.isdir(s) for s in self.input):
            raise OSError('all self.input values should be directories')
        
        num_files = 0
        for indir in self.input:
            for pwd, _, files in os.walk(indir):
                text_files = (f for f in files if is_txt(f) or is_gzip_txt(f))
                for file in text_files:
                    yield os.path.abspath(os.path.join(pwd, file))
                    num_files += 1
        
        if self.length is None:
            logger.info('Caching the number of documents')
            self.length = num_files
    
    def getstream(self):
        """Walk through self.get_file_list() yielding text and metadata"""
        for file in self.get_file_list():
            identifier = self.path_to_id(file)
            yield {
                'meta': identifier,
                'text': read_gzip_or_txt(file)
            }
    
    def get_texts(self):
        """
        Walk through self.getstream() and yield documents.

        The metadata yield pattern follows gensim.corpora.TextCorpus.
        
        """
        logger.info(
            'Using get_texts() %s',
            'with spacy' if self.use_spacy else ''
        )
        docs = self.getstream()
        if self.parallel:
            # get_texts_in_parallel() will handle metadata
            yield from self.get_texts_in_parallel()
        else:
            if self.use_spacy:
                func = ArxivCorpus.preprocess_text_spacy
            else:
                func = ArxivCorpus.preprocess_text
            for doc in docs:
                if self.metadata:
                    yield func(doc['text']), (doc['meta'],)
                else:
                    yield func(doc['text'])

    def get_texts_in_parallel(self):
        """Collapse reading and preprocessing to quickly process a corpus"""
        logger.info(
            'Using get_texts_in_parallel() %s',
            'with spacy' if self.use_spacy else ''
        )
        # jobs is a dict to capture metadata (IDs)
        jobs = {}
        num_cores = max(1, os.cpu_count()-1)
        with futures.ProcessPoolExecutor(max_workers=num_cores) as ppe:
            for doc in self.get_file_list():
                identifier = self.path_to_id(doc)
                job = ppe.submit(_decompress_and_preprocess_wrapper,
                        doc, self.use_spacy)
                # This allows us to iterate through 'jobs'; each job is a key
                jobs[job] = identifier
            for job in futures.as_completed(jobs):
                # dict.pop() (to remove the object) is memory friendly
                identifier = jobs.pop(job)
                if self.metadata:
                    yield job.result(), (identifier,)
                else:
                    yield job.result()

    def init_dictionary(self, dictionary):
        """
        This is a copy-and-paste job from gensim.corpora.textcorpus.TextCorpus.
        
        I needed this to set up creating the dictionary in parallel.

        """
        if dictionary is not None:
            self.dictionary = dictionary
        else:
            self.dictionary = gensim.corpora.Dictionary()
        if self.input is not None:
            if dictionary is None:
                logger.info('Initializing dictionary')
                metadata_setting = self.metadata
                self.metadata = False
                self.dictionary.add_documents(
                    # Always in parallel
                    self.get_texts_in_parallel(), 
                    prune_at=self.prune_dictionary_at
                )
                self.metadata = metadata_setting
            else:
                logger.info(
                    'Input stream provided but dictionary already initialized'
                )
        else:
            logger.warning(
                'No input document stream provided; assuming dictionary ' +
                'will be initialized some other way.'
            )
    
    # FIXME: refactor
    @staticmethod
    def preprocess_text(text, stem=True, stop=True):
        """
        Full preprocessing pipeline.
        
          1. Tokenize
          2. Normalize
          3. Remove stop words
          4. Stem the tokens
        
        """
        stemmer = gensim.parsing.PorterStemmer()
        
        RE_SPLIT_FIRST_PASS = re.compile(r'[\s,]+')
        RE_SPLIT_SECOND_PASS = re.compile(r'[-/\\(){}–—,\[\]]+')
        
        RE_HYPHEN_COLLAPSE = [
            {'search': re.compile(r'x[-—]ray'),          'replace': 'xray'},
            {'search': re.compile(r'e[-—]mail'),         'replace': 'email'},
            {'search': re.compile(r'non[-—]([a-zA-Z])'), 'replace': 'non\\1'},
            {'search': re.compile(r'space[-—]time'),     'replace': 'spacetime'}
        ]
        
        RE_BRACKET_DETRITUS = re.compile(r'[^\[\]]+\[[^\[\]]+')
        RE_LATEX_SEC = re.compile(r'(fig|eqn?)[:a-zA-Z0-9]')
        RE_EDGE_PUNCT = re.compile(r'(?<=^)[^a-zA-Z0-9]+|[^a-zA-Z0-9]+(?=$)')
        RE_ALPHANUM = re.compile(r'[0-9a-zA-Z]')
        RE_POSSESSION = re.compile(r'[\'‘’`][sS]$')
        RE_NUM = re.compile(r'[0-9]')
        
        # split on whitespace and remove whitespace-only tokens
        # normalize to ascii and convert to lowercase
        stream = [
            gensim.corpora.textcorpus.deaccent(w).lower()
            for w in RE_SPLIT_FIRST_PASS.split(text)
        ]
        
        # collapse commonly-hyphenated words
        for regex in RE_HYPHEN_COLLAPSE:
            stream = [regex['search'].sub(regex['replace'], s) for s in stream]
            
        # Remove bracket detritus like blah[blah]
        stream = [s for s in stream if RE_BRACKET_DETRITUS.search(s) is None]

        # Secondary split: hyphens, slashes, parens, braces, etc.
        # https://stackoverflow.com/a/952952/656740
        stream = list(filter(None, it.chain.from_iterable(
            RE_SPLIT_SECOND_PASS.split(s)
            for s in stream
        )))
        
        # remove common LaTeX labels like fig:blah or eq:blah1
        stream = [s for s in stream if RE_LATEX_SEC.search(s) is None]

        # strip edge punctuation
        stream = [RE_EDGE_PUNCT.sub('', s) for s in stream]

        # do not include nonword tokens
        stream = [s for s in stream if RE_ALPHANUM.search(s) is not None]
        
        # remove email addresses
        stream = [s for s in stream if s.find('@') == -1]

        # strip possession
        if stem:
            stream = [RE_POSSESSION.sub('', s) for s in stream]
        
        # remove leftover colon-y things like 'sec:my_great_section'
        stream = [s for s in stream if s.find(':') == -1]
        
        # remove numbers
        stream = [s for s in stream if RE_NUM.search(s) is None]
        
        # remove obvious stopwords
        if stop:
            stream = [
                s for s in stream
                if s not in gensim.corpora.textcorpus.STOPWORDS
            ]
        
        # stem
        if stem:
            stream = [stemmer.stem(s) for s in stream]
        
        # edge punctuation once more
        stream = [RE_EDGE_PUNCT.sub('', s) for s in stream]
        
        return stream
    
    @staticmethod
    def preprocess_text_spacy(text):
        nlp = spacy.load('en_core_web_sm', disable=['ner', 'parser'])
        nlp.max_length = int(5e7)
        
        # 0.1 s/doc
        text = gensim.corpora.textcorpus.deaccent(text)
        
        # 1. Token substitutions: 0.1 s/doc
        RE_SUBSTITUTIONS = [
            {
                'search': re.compile(r'\bnon[-–—]+([a-zA-Z])'),
                'replace': 'non\\1'
            },
            {
                'search': re.compile(r'\bx[-–—]+ray'),
                'replace': 'xray'
            },
            {
                'search': re.compile(r'\bspace[-–—]+time'),
                'replace': 'spacetime'
            },
            {
                # Remove wrongly smashed-together parens
                'search': re.compile(r'(?<!\s)\('),
                'replace': ' ('
            },
            {
                # Remove wrongly smashed-together parens (II)
                'search': re.compile(r'\)(?!\s)'),
                'replace': ') '
            }
        ]

        for rx in RE_SUBSTITUTIONS:
            text = rx['search'].sub(rx['replace'], text)
        

        # 2. Token eliminations: 0.1 s/doc
        RE_X_PRE = re.compile(r'\[(?P<preref>[\w\s–—-]+)\s*\]\s*(?P=preref)')
        RE_X_POST = re.compile(
            r'(?P<postref>[\w–—_-]+)\s*\[\s*(?P=postref)\s*\]'
        )
        RE_X_BRACKETS = re.compile(r'\[[^\[\]\s]+\]')
        RE_X_SPACE = re.compile(r'(?<=\w)\n(?=\w)')
        RE_X_COLON = re.compile(r'\b\w+:\w+\b')
        RE_X_REFNUM = re.compile(r'\b[a-zA-Z]+[0-9]+\b')
        RE_X_EMAIL = re.compile(r'\b[a-zA-Z0-9._+-]+@[a-zA-Z0-9._+-]+\b')
        RE_X_URL = re.compile(r'\b(http|ftp|smb)s?://[^\s]+?\b')
        
        text = RE_X_PRE.sub(' ', text)
        text = RE_X_POST.sub(' ', text)
        text = RE_X_BRACKETS.sub(' ', text)
        text = RE_X_SPACE.sub(' ', text)
        text = RE_X_COLON.sub(' ', text)
        text = RE_X_REFNUM.sub(' ', text)
        text = RE_X_EMAIL.sub(' ', text)
        text = RE_X_URL.sub(' ', text)


        # Tokenization and lemmatization:
        #   - lowercased lemmatized deaccented tokens
        #   - ignore pronouns
        #   - ignore tokens without a-zA-Z (exclusively numbers, punct, space)
        #   - ignore tokens with only 1 word character
        #   - remove edge hyphens
        #   - ignore tokens starting with slashes -- these often seem to be LaTeX
        RE_AZ = re.compile(r'[a-zA-Z]')
        RE_AZ09 = re.compile(r'[a-zA-Z0-9]')
        RE_EDGE_HYPHEN = re.compile(r'^[—–-]|[—–-]$')

        token_stream = [
            RE_EDGE_HYPHEN.sub('', t.lemma_.lower())
            for t in nlp(text)
                if not t.lemma_.startswith('/')
                and t.lemma_ != '-PRON-'
                and RE_AZ.search(t.lemma_)
                and len(RE_AZ09.findall(t.lemma_)) > 1
        ]

        # 0.1 s/doc
        return [t for t in token_stream if t not in gensim.corpora.textcorpus.STOPWORDS]

    @staticmethod
    def path_to_id(path):
        """Get arxiv ID from path"""
        RE_TXTGZ = re.compile(r'\.txt(\.gz)?$', re.I)
        return RE_TXTGZ.sub('', os.path.basename(path))


def is_gzip_txt(path):
    base, ext = [p.lower() for p in os.path.splitext(path)]
    return ext == '.gz' and base.endswith('.txt')

def is_txt(path):
    ext = os.path.splitext(path)[-1].lower()
    return ext == '.txt'

def read_gzip_or_txt(path):
    """Read a file and return a UTF-8 representation"""
    if is_txt(path):
        with open(path, 'r', encoding='utf-8') as infil:
            return infil.read()
    elif is_gzip_txt(path):
        with gzip.GzipFile(path) as infil:
            return infil.read().decode()
    else:
        raise ValueError(f'unsupported file extension in {path}')

def _decompress_and_preprocess_wrapper(path, use_spacy=False):
    """Picklable wrapper for decompressing and preprocessing text."""
    if use_spacy:
        func = ArxivCorpus.preprocess_text_spacy
    else:
        func = ArxivCorpus.preprocess_text
    return func(read_gzip_or_txt(path))
