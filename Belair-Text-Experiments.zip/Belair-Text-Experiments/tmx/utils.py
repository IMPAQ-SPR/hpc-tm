"""Miscellaneous utilities"""

import logging
import os
import pickle as pkl


logger = logging.getLogger(__name__)

def unpickle(pklfile):
    """Unpickle a gensim-created pickled object"""
    with open(pklfile, 'rb') as infil:
        logger.info('Unpickling %s', pklfile)
        return pkl.load(infil)

def pickle(obj, path, overwrite=False):
    """Pickle a Python object"""
    if os.path.exists(path) and not overwrite:
        raise FileExistsError(f'Pickle path {path} already exists.')
    with open(path, 'wb') as outfil:
        logger.info('Pickling object to path %s', path)
        return pkl.dump(obj, outfil)
