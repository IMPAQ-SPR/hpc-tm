"""
Dataset generation and preparation for arXiv source files.

The basic dataset pipeline is:

    gz => unpack => pandoc (TeX) => detex => gzipped text

We assume that all the arXiv source is in some <root>/source directory. The 
various helper files should be in <root> and the text will go into <root>/text 
following the same directory structure.

"""

import gzip
import magic
import os
import re
import shlex
import shutil
import subprocess as sp
import sys
import tarfile


def arxiv_id_from_path(file_path):
    """The arXiv ID is the file's basename without the file extension."""
    return os.path.splitext(os.path.basename(file_path))[0]


def is_gzipped(file_path):
    """Test heuristically if a file is gzipped.
    
    Arguments:
        file_path {str} -- path to file to be tested
    
    Returns:
        bool -- does the file appear to be gzipped?
    """
    ext = os.path.splitext(file_path)[1].lower()
    mime = magic.from_file(file_path, mime=True)
    if ext[:3] == ".gz" or mime == "application/x-gzip":
        return True
    return False


def stage_gzipped_file(file_path, temp_dir):
    """
    Prepare a gzipped arXiv collection for text extraction.
    This function *assumes* a gzipped file.
    
    Arguments:
        file_path {str} -- path to the arXiv gzipped file
        temp_dir {str} -- path to the temporary directory root
    
    Returns:
        str -- path to a copied and decompressed arXiv source collection
    """
    # Create the new directory
    arxiv_id = arxiv_id_from_path(file_path)
    newdir_path = os.path.join(temp_dir, arxiv_id)
    os.mkdir(newdir_path)

    # Copy the file to the new path
    shutil.copy2(file_path, newdir_path)

    # Unpack the file, simulating 'gunzip'
    new_file_path = os.path.join(newdir_path, os.path.basename(file_path))
    ungz_file_path = os.path.splitext(new_file_path)[0]
    with open(new_file_path, "rb") as infil:
        with open(ungz_file_path, "wb") as outfil:
            outfil.write(gzip.decompress(infil.read()))

    # Return the new un-gzipped path
    return ungz_file_path


def untar_arxiv_file(path):
    """Try to extract a tarball into a sensible directory.
    
    Arguments:
        path {str} -- path to the tarfile
    
    Returns:
        str -- path to the untar directory
    """
    try:
        file = tarfile.TarFile(path)
        dest = os.path.join(os.path.dirname(path), "axv-untar")
        file.extractall(path=dest)
    except tarfile.ReadError:
        sys.stderr.write(f'EXCEPTN: tarfile.ReadError: {path}\n')
        return None
    return dest


def collect_text_files(*paths):
    """Generator yielding paths to all text-like files."""
    for path in paths:
        # Edge case when untar fails
        if path is None:
            continue
        # Edge case where path doesn't exist
        if not os.path.exists(path):
            sys.stderr.write("NB! path didn't exist in collect_text_files() \n")
            continue
        # If directory, traverse
        if os.path.isdir(path):
            yield from collect_text_files(
                *[os.path.join(path, p) for p in os.listdir(path)]
            )
        # Otherwise, handle individual types
        else:
            ext = os.path.splitext(os.path.basename(path))[1].lower()
            mime_type = magic.from_file(path, mime=True)
            if mime_type == "text/x-tex" or ext == ".tex":
                yield path
            elif mime_type == "application/x-tar" or ext == ".tar":
                untar_path = untar_arxiv_file(path)
                yield from collect_text_files(untar_path)
            else:
                continue


def grep(path):
    r"""Reimplement grep badly to find \begin{document} and \input."""
    # NB: errors='ignore' isn't great, but OK for grep
    with open(path, "r", errors="ignore") as infil:
        for line in infil:
            if re.search(r"\\begin[\s%]*\{document\}", line, re.I) is not None:
                return True
            if re.search(r"\\input", line, re.I) is not None:
                return True
    return False


def gather_useable_text(*paths):
    """Find actual LaTeX files (remove sty, cls, etc)."""
    SKIP_EXTS = (".cls", ".sty")
    keep = []
    for path in paths:
        # Test obviously unwanted extensions
        ext = os.path.splitext(os.path.basename(path))[1].lower()
        if ext in SKIP_EXTS:
            continue
        # Check for \documentclass
        if grep(path):
            keep += [path]
    return keep


def iconv(source_path):
    """Apply iconv in a desparate attempt to normalize the text."""
    cmd = f'iconv -c -t UTF-8 "{source_path}"'
    job = sp.run(shlex.split(cmd), stdout=sp.PIPE)
    return job.stdout


def pandoc(source_bytes, template_path, timeout=10, sed=True):
    """Run through pandoc to remove latex macros"""
    # Remove \input commands that choke pandoc
    if sed:
        sed_cmd = f"sed 's/^.*\\input.*$//'"
        sed_job = sp.run(
            shlex.split(sed_cmd),
            input=source_bytes,
            stdout=sp.PIPE,
            stderr=sp.DEVNULL)
        source_bytes = sed_job.stdout
    
    cmd = (
        "pandoc -f latex+latex_macros-auto_identifiers -t latex "
        + f'--template "{template_path}"'
    )
    job = sp.run(
        shlex.split(cmd),
        input=source_bytes,
        stdout=sp.PIPE,
        stderr=sp.DEVNULL,
        timeout=timeout
    )
    return job.stdout


def detex(source_bytes):
    """Run a byte string through detex"""
    job = sp.run("detex", input=source_bytes, stdout=sp.PIPE)
    return job.stdout.decode()
