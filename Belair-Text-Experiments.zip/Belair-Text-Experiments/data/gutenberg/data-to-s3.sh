#!/usr/bin/env bash

# Download text files & READMEs only
# As of 2019-01-21, this is about 40 GB of data
rsync -avP --del --include="*/" --include="*.txt" --exclude="*" \
    aleph.gutenberg.org::gutenberg gutenberg

rsync -avP --del --include="*/" --include="README*" --exclude="*" \
    aleph.gutenberg.org::gutenberg gutenberg

rsync -avP --del --include="*/" --include="*TXT" --exclude="*" \
    aleph.gutenberg.org::gutenberg gutenberg

rsync -avP --del --include="*/" --include="GUTINDEX*" --exclude="*" \
    aleph.gutenberg.org::gutenberg gutenberg


# Put to S3
aws s3 sync gutenberg s3://eri-belair-hpc/text-mining/data/gutenberg
