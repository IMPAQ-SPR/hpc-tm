#!/usr/bin/env bash

# Get Project Gutenberg text data out of S3
aws s3 sync s3://eri-belair-hpc/text-mining/data/gutenberg data
