#!/usr/bin/env bash
# Run directories through the tool


EXEDIR=/eri/work/work/data/arxiv
LOGDIR=/eri/work/work/data/arxiv/logs
OUTDIR=/eri/work/work/data/arxiv/text
TMPDIR=/eri/work/tmp


if [[ $# -lt 1 ]]; then
    echo "Error: require at least 1 input directory"
    exit 1
fi

for indir in $@; do
    echo "$indir"
    
    if [[ ! -d "$indir" ]]; then
        echo "Error: path $indir is not a directory"
        exit 2
    fi

    process_dt=$(basename $indir)
    this_outdir="$OUTDIR/$process_dt"
    
    mkdir -vp "$this_outdir"

    python3 "$EXEDIR/extract-tool.py" \
        -n 16 -d "$TMPDIR" -o "$this_outdir" \
        --template "$EXEDIR/pandoc-template.tex" \
        "$indir"/* \
        &> "$LOGDIR/$process_dt.txt"

done
