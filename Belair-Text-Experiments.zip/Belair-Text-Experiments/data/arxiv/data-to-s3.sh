#!/usr/bin/env bash

# Download raw arXiv source -- stored by arXiv in a "requester pays" bucket
# Get the manifest
aws s3 cp --request-payer requester \
    s3://arxiv/src/arXiv_src_manifest.xml \
    s3://eri-belair-hpc/text-mining/data/arxiv/source/

# Get the first 250 GB or so: 1990s through 2012
aws s3 cp --recursive --request-payer requester \
    --exclude='*' --include='*_9*' \
    s3://arxiv/src s3://eri-belair-hpc/text-mining/data/arxiv/source/

aws s3 cp --recursive --request-payer requester \
    --exclude='*' --include='*_0[0-9][!_][!_]_*' \
    s3://arxiv/src s3://eri-belair-hpc/text-mining/data/arxiv/source/

aws s3 cp --recursive --request-payer requester \
    --exclude='*' --include='*_1[0-2][!_][!_]_*' \
    s3://arxiv/src s3://eri-belair-hpc/text-mining/data/arxiv/source/
