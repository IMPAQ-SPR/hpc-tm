#!/usr/bin/env bash

# Get arXiv text data out of S3
aws s3 sync \
    s3://eri-belair-hpc/text-mining/data/arxiv/source \
    arxiv-src
