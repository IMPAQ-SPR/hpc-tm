# arXiv Source Files

See: <https://arxiv.org/help/bulk_data_s3>

According to arXiv, there were about 150 GB of source files as of January 2011. After examining the manifest, we've seen:

  - The total size is 1.2 TB.
  - The total item count is 1.483 million.

The item and size counts are also rapidly increasing:

| year       | items (k) |   size (gb) | cml_size (gb) |
| ---        | ---       | ---         | ---           |
| 1991-01-01 |   0.306   |   0.00620   |     0.00620   |
| 1992-01-01 |   3.26    |   0.0677    |     0.0739    |
| 1993-01-01 |   6.74    |   0.206     |     0.280     |
| 1994-01-01 |  10.1     |   0.418     |     0.698     |
| 1995-01-01 |  13.0     |   0.674     |     1.37      |
| 1996-01-01 |  15.9     |   0.920     |     2.29      |
| 1997-01-01 |  19.6     |   1.37      |     3.66      |
| 1998-01-01 |  24.2     |   1.99      |     5.66      |
| 1999-01-01 |  27.7     |   2.46      |     8.12      |
| 2000-01-01 |  30.6     |   2.96      |    11.1       |
| 2001-01-01 |  33.2     |   3.51      |    14.6       |
| 2002-01-01 |  36.1     |   4.23      |    18.8       |
| 2003-01-01 |  39.4     |   5.05      |    23.9       |
| 2004-01-01 |  43.7     |   6.44      |    30.3       |
| 2005-01-01 |  46.8     |   8.37      |    38.7       |
| 2006-01-01 |  50.2     |  10.0       |    48.7       |
| 2007-01-01 |  55.6     |  12.4       |    61.1       |
| 2008-01-01 |  58.9     |  18.6       |    79.7       |
| 2009-01-01 |  64.0     |  26.0       |   106.        |
| 2010-01-01 |  70.1     |  41.0       |   147.        |
| 2011-01-01 |  76.6     |  50.4       |   197.        |
| 2012-01-01 |  84.6     |  66.1       |   263.        |
| 2013-01-01 |  92.6     |  80.8       |   344.        |
| 2014-01-01 |  97.5     |  92.0       |   436.        |
| 2015-01-01 | 105.      | 114.        |   550.        |
| 2016-01-01 | 113.      | 136.        |   686.        |
| 2017-01-01 | 124.      | 162.        |   848.        |
| 2018-01-01 | 141.      | 204.        |  1052.        |


## Paper Cleaning

The LaTeX archives can take one of several forms, but in general:

 1. Extract the paper's GZip archive
 2. Extract the paper's tarball if necessary
 3. Pass the LaTeX source through a pipeline including:
    1. `pandoc`
        - `-f latex+latex_macros-auto_identifiers`
        - `-t latex`
        - `--template template.tex`, with a basic pandoc template
    2. `detex`

For now, we are including end notes and the bibliography in the output but attempting to strip the mathematics.

### Notes and Design Decisions

This pipeline has been quickly designed to be fast and simple. As a result, we're making a few decisions that I probably wouldn't otherwise make.

  - Unconvertible characters are dropped by *iconv* in the interests of 
    streamlining the pipeline. We could revisit the whole issue of character
    encodings in the future
  - I'm ending *pandoc* processing after 10 seconds. Reasonable LaTeX documents 
    seem to be translated nearly instantaneously in my experience, so a 
    multi-second threshold should be OK
     - That said, I _do_ gain a few documents per month moving from five
       seconds to ten
  - I'm including the bibliography in the final text
