# Arxiv.org Pipeline Log Files

Log files produced during extractions can be downloaded from Amazon S3:

    aws s3 sync s3://eri-belair-hpc/text-mining/data/arxiv/logs .
