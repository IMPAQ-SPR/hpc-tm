## Read the arXiv source manifest XML file
## TS, 2019-01-21

library(magrittr)
library(tidyverse)
library(xml2)


arxiv <- read_xml("arXiv_src_manifest.xml") %>% 
  xml_find_all(".//file") %>% 
  map_df(~ {
    node <- .x
    node_names <- xml_name(xml_children(node))

    tmp <- map(node_names, ~ {
     xml_text(xml_contents(xml_child(node, .x)), trim = T)
    })

    names(tmp) <- node_names
    as_tibble(tmp)
  }) %>% 
  mutate_at(vars(num_items:size), as.integer) %>% 
  mutate_at(vars(timestamp), as.Date)


# Total size is 1.052 TB!
sum(arxiv$size) / 1e12

# Total files: 1.483 M
sum(arxiv$num_items) / 1e6

# Size & number of files per year
#   - through 2013: < 250 GB
#   - through 2016: < 500 GB
#   - through 2017: < 750 GB
#   - through 2018:   1 TB
#   - through 2019: > 1 TB
arxiv %>% 
  mutate(year = lubridate::ymd(str_c(str_sub(yymm, 1, 2), "0101"))) %>% 
  group_by(year) %>% 
  summarize(
    items_k = sum(num_items) / 1e3,
    size_gb = sum(as.numeric(size)) / 1e9) %>% 
  arrange(year) %>% 
  mutate(cml_size_gb = cumsum(size_gb)) %>% {
    print(., n = Inf)
  } %>% 
  gather(k, v, -year) %>% 
  ggplot(aes(year, v, color = k, fill = k)) + 
  geom_bar(stat = "identity") + 
  facet_wrap(~ k, scales = "free_y") + 
  scale_color_discrete(guide = F) + 
  scale_fill_discrete(guide = F) + 
  theme(aspect.ratio = 3 / 4,
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5))

# Same, but by month
arxiv %>% 
  mutate(abbrv_ts = lubridate::ymd(str_c(yymm, "01"))) %>% 
  group_by(abbrv_ts) %>% 
  summarize(items_k = sum(num_items) / 1e3,
            size_gb = sum(as.numeric(size)) / 1e9) %>% 
  arrange(abbrv_ts) %>% 
  mutate(cml_size_gb = cumsum(size_gb)) %>% 
  gather(k, v, -abbrv_ts) %>% 
  ggplot(aes(abbrv_ts, v, color = k, fill = k)) + 
  geom_bar(stat = "identity") + 
  facet_wrap(~ k, scales = "free_y") + 
  theme(aspect.ratio = 3 / 4,
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5))
