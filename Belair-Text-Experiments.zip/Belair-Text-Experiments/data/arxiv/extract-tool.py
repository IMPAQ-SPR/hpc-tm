r"""
Batch-extract a set of arXiV gzip archives to text files.

This script is pretty naive: it doesn't, for example, try to handle complicated 
dissertation-like LaTeX setups with multiple input files. Rather, it process 
them separately and smashes their results together. In LDA (bag of words) this 
shouldn't matter.

TODO: Parse these TeX files in their in source directories? This might cause
other issues with repeated \inputs, but it would solve some warnings.

"""

import argparse
import os
import shutil
import subprocess as sp
import sys
import tempfile
import time

sys.path.append('/Users/tshafer/Projects/Belair/Local/experiments')
from concurrent import futures
from datetime import datetime
from tmx.datasets import arxiv


# Definitions for final counts
R_NOT_GZIPPED = 0
R_NO_LATEX_SOURCE = 1
R_NO_EXTRACTED_TEXT = 2
R_PROCESSED_OK = 3


def log(msg):
    """Write log to stderr and flush.
    
    Arguments:
        msg {str} -- message
    """
    sys.stderr.write(msg.strip() + '\n')
    sys.stderr.flush()


def clog(msg):
    """Write log message with a comment character prepended."""
    return log('# ' + msg)


def process_path(path, tmpdir, args):
    """
    Attempt to process an arXiv path (probably gzipped).
    If various bad things happen (not a gzipped file, no LaTeX source, 
    unreadable source, etc.) then return the appropriate error code. If all 
    goes well, though, write the text and return a happy code.
    
    Arguments:
        path {str} -- path to the arXiv archive
        tmpdir {str} -- path to a temporary directory
        args {argparse object} -- command-line options
    
    Returns:
        int -- result code
    """
    arxiv_id = arxiv.arxiv_id_from_path(path)

    # Non-gzip files are skipped
    if not arxiv.is_gzipped(path):
        log(f'SKIP: {arxiv_id}: not gzipped')
        return R_NOT_GZIPPED

    # Gzipped files are processed
    staged_path = arxiv.stage_gzipped_file(path, tmpdir)
    textlike_files = arxiv.collect_text_files(staged_path)
    arxiv_text_files = arxiv.gather_useable_text(*textlike_files)

    if len(arxiv_text_files) < 1:
        log(f'SKIPPED: {arxiv_id} has 0 source file(s)')
        return R_NO_LATEX_SOURCE

    # Process the text together
    log(f'PROCESS: {arxiv_id} has {len(arxiv_text_files)} source file(s)')

    text = []
    for path in arxiv_text_files:
        iconv = arxiv.iconv(path)
        # Ignore errors b/c we're just using this for counting
        if len(iconv.decode(errors='ignore').strip()) < 1:
            continue
        try:
            pandoc = arxiv.pandoc(iconv, template_path=args.template)
            if len(pandoc.decode().strip()) < 1:
                continue
        except sp.TimeoutExpired:
            log(f'TIMEOUT: {arxiv_id}: pandoc timed out')
            continue
        
        text += [arxiv.detex(pandoc)]

    fulltext = '\n\n'.join(text).strip()
    if len(fulltext) < 1:
        log(f'ERRORED: {arxiv_id} produced no text')
        return R_NO_EXTRACTED_TEXT

    # If we have text, write it
    chars = len(fulltext)
    log(f'WRITING: {arxiv_id} produced {chars} characters')

    outpath = os.path.join(args.o, f'{arxiv_id}.txt')
    with open(outpath, 'w') as outfil:
        outfil.write(fulltext)

    return R_PROCESSED_OK


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-n', type=int, default=1,
        help='number of processor cores')
    parser.add_argument(
        '-k', action='store_true',
        help='do not delete temporary directory')
    parser.add_argument(
        '-d', type=str,
        help='temporary directory root')
    parser.add_argument(
        '--template', type=str, required=True,
        help='pandoc LaTeX template')
    parser.add_argument(
        '-o', metavar='<outdir>', type=str, required=True,
        help='output directory')
    parser.add_argument('i', metavar='<input file>', type=str, nargs='+')
    cli = parser.parse_args()

    # Identify all input files
    for infil in cli.i:
        if not os.path.isfile(infil):
            quit(f'Error: "{infil}" is not a file or does not exist')

    # Ensure output dir is present
    if not os.path.exists(cli.o) or not os.path.isdir(cli.o):
        quit(f'Error: "{cli.o}" is not a directory or does not exist')

    # Ensure template is present
    if not os.path.exists(cli.template):
        quit(f'Error: "{cli.template}" does not exist')

    clog(f'Begin: {datetime.now()}')
    clog(f'Using template: {cli.template}')
    clog(f'Found {len(cli.i)} input files')
    clog(f'Writing to {cli.o}')

    # Create a place for unpacking this stuff
    tempdir = tempfile.mkdtemp(dir=cli.d)
    clog(f'Using temporary directory {tempdir}')

    # Run through the pipeline, keeping a log
    t_start = time.time()

    counts = {
        R_NOT_GZIPPED: 0,
        R_NO_LATEX_SOURCE: 0,
        R_NO_EXTRACTED_TEXT: 0,
        R_PROCESSED_OK: 0,
    }

    with futures.ProcessPoolExecutor(max_workers=cli.n) as fex:
        jobs = []
        for i, infil in enumerate(cli.i):
            jobs += [fex.submit(process_path, infil, tempdir, cli)]

    for j in futures.as_completed(jobs, timeout=10):
        counts[j.result()] += 1
    t_end = time.time()

    # Clean up
    if not cli.k:
        shutil.rmtree(tempdir)
        clog(f'Destroyed temporary directory {tempdir}')

    # Final statistics
    clog(f'Run time: {t_end-t_start:.1f} seconds')
    clog( 'Final statistics:')
    clog(f'Input ......... : {len(cli.i)}')
    clog(f'Not-gzipped ... : {counts[R_NOT_GZIPPED]}')
    clog(f'No source ..... : {counts[R_NO_LATEX_SOURCE]}')
    clog(f'No text ....... : {counts[R_NO_EXTRACTED_TEXT]}')
    clog(f'Processed ..... : {counts[R_PROCESSED_OK]}')
